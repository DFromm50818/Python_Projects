print("Welcome to the rollercoaster!")
height = int(input("What is your height in cm? "))

if height > 120:
  print("Ride it Baby!")
else:
  print("It some Fruchtzwerge!")