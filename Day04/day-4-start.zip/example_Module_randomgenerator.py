import my_modul

print(my_modul.random_number)