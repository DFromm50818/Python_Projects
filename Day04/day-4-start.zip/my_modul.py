import random

random_number = random.randint(1,1000000)